dotnet pack ./LocalStorage/LocalStorage.csproj -c Release --include-symbols
