﻿namespace LocalStorageTests.Stubs
{
    public class Joke
    {
        public int Id { get; set; }
        public string Text { get; set; }
    }
}
