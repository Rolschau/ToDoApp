using System.Collections.Generic;

namespace Hanssens.Net
{
    internal class Store : Dictionary<string, string>
    {
        
    }
}