﻿using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("LocalStorage.Tests")]