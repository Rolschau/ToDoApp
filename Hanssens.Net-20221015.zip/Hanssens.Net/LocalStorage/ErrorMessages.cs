namespace Hanssens.Net
{
    public static class ErrorMessages
    {
        public static string CannotExecuteStoreInReadOnlyMode = "Cannot execute Store because ReadOnly mode is explicitly enabled.";
        public static string CannotExecutePersistInReadOnlyMode = "Cannot execute Persist because ReadOnly mode is explicitly enabled.";
    }
}